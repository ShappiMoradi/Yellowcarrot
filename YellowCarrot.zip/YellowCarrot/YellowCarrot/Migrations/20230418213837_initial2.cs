﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace YellowCarrot.Migrations
{
    /// <inheritdoc />
    public partial class initial2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "IngridientID",
                table: "Ingridients",
                newName: "ingridientID");

            migrationBuilder.UpdateData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 2,
                column: "Name",
                value: "Nötfärs");

            migrationBuilder.UpdateData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 3,
                column: "Name",
                value: "Lök");

            migrationBuilder.UpdateData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 4,
                column: "Name",
                value: "Vitlök");

            migrationBuilder.InsertData(
                table: "Ingridients",
                columns: new[] { "ingridientID", "Name", "Quantity", "RecipeID" },
                values: new object[,]
                {
                    { 5, "Krossade tomater", null, 1 },
                    { 6, "Tomatpure", null, 1 },
                    { 7, "Köttbuljong", null, 1 },
                    { 8, "Kryddor", null, 1 },
                    { 9, "Vatten", null, 1 },
                    { 10, "Parmesan", null, 1 }
                });

            migrationBuilder.UpdateData(
                table: "Recipes",
                keyColumn: "RecipeId",
                keyValue: 1,
                column: "RecipeName",
                value: "Spaghetti & Köttfärssås");

            migrationBuilder.InsertData(
                table: "Recipes",
                columns: new[] { "RecipeId", "RecipeName", "TagsID" },
                values: new object[] { 2, "Brownies", 2 });

            migrationBuilder.InsertData(
                table: "Ingridients",
                columns: new[] { "ingridientID", "Name", "Quantity", "RecipeID" },
                values: new object[,]
                {
                    { 11, "Smör", null, 2 },
                    { 12, "Kakao", null, 2 },
                    { 13, "Ägg", null, 2 },
                    { 14, "Strösocker", null, 2 },
                    { 15, "Salt", null, 2 },
                    { 16, "Vaniljpulver", null, 2 },
                    { 17, "Vetemjöl", null, 2 },
                    { 18, "Bakpulver", null, 2 },
                    { 19, "Rostade hasselnötter", null, 2 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "Ingridients",
                keyColumn: "ingridientID",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "Recipes",
                keyColumn: "RecipeId",
                keyValue: 2);

            migrationBuilder.RenameColumn(
                name: "ingridientID",
                table: "Ingridients",
                newName: "IngridientID");

            migrationBuilder.UpdateData(
                table: "Ingridients",
                keyColumn: "IngridientID",
                keyValue: 2,
                column: "Name",
                value: "Köttfärssås");

            migrationBuilder.UpdateData(
                table: "Ingridients",
                keyColumn: "IngridientID",
                keyValue: 3,
                column: "Name",
                value: "Vitlök");

            migrationBuilder.UpdateData(
                table: "Ingridients",
                keyColumn: "IngridientID",
                keyValue: 4,
                column: "Name",
                value: "Parmesan");

            migrationBuilder.UpdateData(
                table: "Recipes",
                keyColumn: "RecipeId",
                keyValue: 1,
                column: "RecipeName",
                value: "Spaghetti");
        }
    }
}
