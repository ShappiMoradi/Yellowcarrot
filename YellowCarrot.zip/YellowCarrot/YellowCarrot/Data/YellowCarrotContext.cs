﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using YellowCarrot.Model;

namespace YellowCarrot.Data
{
    public class YellowCarrotContext : DbContext

    {
        public YellowCarrotContext()
        {

        }

        public YellowCarrotContext(DbContextOptions Options) : base(Options)
        {

        }

        public virtual DbSet<Recipe> Recipes { get; set; }

        public virtual DbSet<Ingridient> Ingridients { get; set; }

        public virtual DbSet<Tags> Tags { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=YellowCarrot;Trusted_Connection=True;");


        }

       
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Recipe>().HasData(new Recipe
            {
                RecipeId = 1,
                RecipeName = "Spaghetti & Köttfärssås",
                TagsID = 1


            }, new Recipe()
            {
                RecipeId = 2,
                RecipeName = "Brownies",
                TagsID = 2
            });

            //Lista med ingredienser för mat och bakning 

            modelBuilder.Entity<Tags>().HasData(new Tags
            {
                TagNameId = 1,
                Name = "Food"
            }, new Tags()
            {
                TagNameId = 2,
                Name = "Baking"
            });

            // Ingredienser för Spaghetti & Köttfärssås

            modelBuilder.Entity<Ingridient>().HasData(new Ingridient
            {

                ingridientID = 1,
                Name = "Spaghetti",
                RecipeID = 1,



            }, new Ingridient()
            {
                ingridientID = 2,
                Name = "Nötfärs",
                RecipeID = 1,


            }, new Ingridient()
            {
                ingridientID = 3,
                Name = "Lök",
                RecipeID = 1,

            }, new Ingridient()
            {
                ingridientID = 4,
                Name = "Vitlök",
                RecipeID = 1

            }, new Ingridient()
            {
                ingridientID = 5,
                Name = "Krossade tomater",
                RecipeID = 1

            }, new Ingridient()
            {
                ingridientID = 6,
                Name = "Tomatpure",
                RecipeID = 1

            }, new Ingridient()

            {
                ingridientID = 7,
                Name = "Köttbuljong",
                RecipeID = 1

            }, new Ingridient()
            {
                ingridientID = 8,
                Name = "Kryddor",
                RecipeID = 1

            }, new Ingridient()
            {
                ingridientID = 9,
                Name = "Vatten",
                RecipeID = 1

            }, new Ingridient()
            {
                ingridientID = 10,
                Name = "Parmesan",
                RecipeID = 1
        });

            // Ingredienser för bakning av Brownies

            modelBuilder.Entity<Ingridient>().HasData(new Ingridient
            {

                ingridientID = 11,
                Name = "Smör",
                RecipeID = 2



            }, new Ingridient()
            {
                ingridientID = 12,
                Name = "Kakao",
                RecipeID = 2


            }, new Ingridient()
            {
                ingridientID = 13,
                Name = "Ägg",
                RecipeID = 2

            }, new Ingridient()
            {
                ingridientID = 14,
                Name = "Strösocker",
                RecipeID = 2

            }, new Ingridient()
            {
                ingridientID = 15,
                Name = "Salt",
                RecipeID = 2

            }, new Ingridient()
            {
                ingridientID = 16,
                Name = "Vaniljpulver",
                RecipeID = 2

            }, new Ingridient()

            {
               ingridientID = 17,
                Name = "Vetemjöl",
                RecipeID = 2

            }, new Ingridient()
            {
                ingridientID = 18,
                Name = "Bakpulver",
                RecipeID = 2

            }, new Ingridient()
            {
                ingridientID = 19,
                Name = "Rostade hasselnötter",
                RecipeID = 2

            });


        }
    }
}
