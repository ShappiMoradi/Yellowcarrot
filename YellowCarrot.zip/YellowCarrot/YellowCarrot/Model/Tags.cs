﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YellowCarrot.Model
{
    public class Tags
    {
        [Key]
        public int TagNameId { get; set; }
        public string Name { get; set; } = null!;

        public List <Recipe> recipes { get; set; } = null!;


    }
}
