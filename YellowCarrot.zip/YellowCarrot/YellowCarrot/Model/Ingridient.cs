﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YellowCarrot.Model
{
    public class Ingridient
    {
        public int ingridientID { get; set; }
        public string Name { get; set; } = null!;   
        public int RecipeID { get; set; }    

        public Recipe recipe { get; set; } = null!;

        public string? Quantity { get; set;}




    }
}
