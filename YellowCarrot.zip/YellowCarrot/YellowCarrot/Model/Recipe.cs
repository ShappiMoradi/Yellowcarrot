﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YellowCarrot.Model
{
   public class Recipe
    {
        [Key]
        public int RecipeId { get; set; }
        public string RecipeName { get; set; } = null!;

        public List <Ingridient>? Ingridients { get; set; }

        public int? TagsID { get; set; }
        public Tags tags { get; set; } = null;

    }
}
