﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YellowCarrot.Data;
using YellowCarrot.Model;

namespace YellowCarrot.Repos
{
    public class IngridentRepo
    {
        private readonly YellowCarrotContext context;

        public IngridentRepo(YellowCarrotContext context)
        {
            this.context = context;
        }

        public List<Ingridient> GetIngridients()
        {
            return context.Ingridients.ToList();
        }

        // Skickar alla ingredienser till det recept som har samma receptID
        public List<Ingridient> GetIngridient(int recipeId)
        {
            return context.Ingridients.Where(x => x.RecipeID == recipeId).ToList();

        }

        // Lägger till/tar bort ingredienser och uppdaterar listan med hjälp av databasen
        
        // Lägg till
        public void AddIngridient(Ingridient addingridient)
        {
            context.Ingridients.Add(addingridient);
        }

        //Ta bort
        public void RemoveIngridient(Ingridient Deleteingridient)
        {
            context.Ingridients.Remove(Deleteingridient);
        }
        //Uppdatera
        public void UpdateIngridient(Ingridient Updateingridient)
        {
            context.Ingridients.Update(Updateingridient);
        }

    }
}
