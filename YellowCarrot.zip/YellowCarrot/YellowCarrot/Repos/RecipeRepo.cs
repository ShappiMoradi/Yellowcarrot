﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YellowCarrot.Data;
using YellowCarrot.Model;

namespace YellowCarrot.Repos
{
    public class RecipeRepo
    {
        private readonly YellowCarrotContext context;


        public RecipeRepo(YellowCarrotContext context)
        {
            this.context = context;
        }


        // Lägg till Recept
        public void AddRecipe(Recipe recipe)
        {
            context.Recipes.Add(recipe);
        }

        // Hämta receptet
        public void GetRecipe(Recipe recipe)
        {
            context.Recipes.Add(recipe);
        }
        // recept lista
        public List<Recipe> GetAllRecipes()
        {
            return context.Recipes.ToList();
        }


        // Ta bort recept
        public void RemoveRecipe(Recipe recipe)
        {
            context.Recipes.Remove(recipe);
        }

        // Uppdatera
        public void UpdateRecipe(Recipe recipe)
        {
            context.Recipes.Update(recipe);
        }
    }
}
