﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YellowCarrot.Data;
using YellowCarrot.Model;

namespace YellowCarrot.Repos
{
    internal class TagRepo
{

        private readonly YellowCarrotContext context;
        public TagRepo(YellowCarrotContext context)
        {
            this.context = context;
        }

        public List<Tags> GetTags()
        {
            return context.Tags.ToList();
        }

      

    }
}
